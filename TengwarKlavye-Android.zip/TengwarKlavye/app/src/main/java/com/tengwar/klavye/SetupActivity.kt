package com.tengwar.klavye

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Uygulamanın açılış ekranı — artık sohbette birlikte tasarladığımız
 * "Tengwar Academy" arayüzünü (Ana Sayfa / Rehber / Klavye / Hakkında
 * sekmeleri) AYNI HTML/CSS/JS kodundan (assets/setup_screen.html) bir
 * WebView içinde gösteriyor. Klavyede kullandığımız yaklaşımın aynısı:
 * görünüm artifact'teki ile birebir aynı olsun diye native View yerine
 * WebView kullanıyoruz.
 *
 * window.AndroidSetup köprüsü, sayfanın gerçek klavye durumunu okumasını
 * ve sistemin klavye ayarları / klavye seçici penceresini açmasını sağlıyor.
 */
class SetupActivity : Activity() {

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.setBackgroundColor(android.graphics.Color.parseColor("#1b2e24"))
        webView.addJavascriptInterface(JsBridge(), "AndroidSetup")
        webView.loadUrl("file:///android_asset/setup_screen.html")

        setContentView(webView)
    }

    override fun onResume() {
        super.onResume()
        // Kullanıcı sistem ayarlarından (klavyeyi etkinleştir/seç) uygulamaya
        // geri döndüğünde sayfanın kendi "visibilitychange" dinleyicisi zaten
        // durumu tazeliyor; ekstra bir şey yapmaya gerek yok.
    }

    private inner class JsBridge {

        @JavascriptInterface
        fun openInputMethodSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        @JavascriptInterface
        fun showKeyboardPicker() {
            runOnUiThread {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        /** Klavyemiz, sistemde etkinleştirilmiş klavyeler listesinde mi? */
        @JavascriptInterface
        fun isKeyboardEnabled(): Boolean {
            val enabled = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_INPUT_METHODS
            ) ?: return false
            return enabled.contains(packageName)
        }

        /** Klavyemiz, o an sistemde SEÇİLİ (varsayılan) giriş yöntemi mi? */
        @JavascriptInterface
        fun isKeyboardSelected(): Boolean {
            val current = Settings.Secure.getString(
                contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD
            ) ?: return false
            return current.contains(packageName)
        }
    }
}
