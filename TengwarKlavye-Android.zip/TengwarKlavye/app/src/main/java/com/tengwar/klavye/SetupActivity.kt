package com.tengwar.klavye

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Klavyeyi native bir "kurulum sihirbazı" ile açıklayan basit başlangıç ekranı.
 * Kullanıcıyı önce sistem ayarlarında klavyeyi ETKİNLEŞTİRMEYE, sonra aktif
 * giriş yönteminde bu klavyeyi SEÇMEYE yönlendirir (Android'in iki aşamalı,
 * standart üçüncü parti klavye akışı budur).
 */
class SetupActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.setup_title)
            textSize = 22f
            setTextColor(Color.parseColor("#364963"))
            setPadding(0, 0, 0, 48)
        })

        root.addView(TextView(this).apply {
            text = getString(R.string.setup_step1)
            textSize = 15f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = getString(R.string.btn_enable)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })

        root.addView(TextView(this).apply {
            text = getString(R.string.setup_step2)
            textSize = 15f
            setPadding(0, 48, 0, 16)
        })

        root.addView(Button(this).apply {
            text = getString(R.string.btn_choose)
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })

        setContentView(root)
    }
}
