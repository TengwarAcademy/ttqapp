package com.tengwar.klavye

import android.annotation.SuppressLint
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import java.util.concurrent.CountDownLatch

/**
 * Türkçe Tengwar-Quenya sistem klavyesi (v3 — WebView tabanlı).
 *
 * Önceki sürüm klavyeyi native Android View'larla (TextView/LinearLayout vb.)
 * elle yeniden çiziyordu; bu, tarayıcıdaki HTML/CSS önizlemesiyle ASLA piksel
 * piksel aynı olamazdı (iki tamamen farklı çizim sistemi). Bunun yerine artık
 * klavye, sohbette birlikte geliştirdiğimiz AYNI HTML/CSS/JS dosyasını
 * (assets/keyboard.html — tengwar-android-onizleme.html'in "üretim" sürümü)
 * bir WebView içinde çalıştırıyor. Görünüm, geçişler, popup'lar, fontlar
 * artifact'teki ile birebir aynı koddan geliyor. HTML/JS tarafı, gerçek
 * cihazda olduğunu şu köprü (window.AndroidKeyboard) üzerinden anlıyor ve
 * hedef uygulamaya doğrudan yazıyor.
 *
 * Genişlik: WebView, IME'nin kendisine ayırdığı tam ekran genişliğini
 * kullanıyor; klavyenin kendi JS'i (equalizeKeyWidths) tuş genişliklerini bu
 * gerçek genişliğe göre hesaplıyor — bu sayede farklı telefon/tablet ekran
 * boyutlarına otomatik uyum sağlanıyor.
 */
class TengwarIME : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null

    override fun onCreateInputView(): View {
        val container = FrameLayout(this)
        val wv = createWebView()
        webView = wv
        container.addView(
            wv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320))
        )
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Her yeni giriş alanına geçildiğinde klavyeyi baştan yükleyip
        // (mod/sayfa durumunu sıfırlayıp) temiz başlıyoruz.
        if (!restarting) {
            webView?.loadUrl("file:///android_asset/keyboard.html")
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun createWebView(): WebView {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.allowFileAccess = true
        wv.setBackgroundColor(android.graphics.Color.parseColor("#1b2e24"))
        wv.addJavascriptInterface(JsBridge(), "AndroidKeyboard")
        wv.loadUrl("file:///android_asset/keyboard.html")
        return wv
    }

    /** WebView içindeki JavaScript'in çağırdığı köprü. Bu metodlar WebView'in
     *  kendi arka plan thread'inde çalışır; InputConnection işlemlerini ana
     *  thread'e (UI thread) taşımamız gerekiyor. */
    private inner class JsBridge {

        @JavascriptInterface
        fun commitText(text: String, plain: Boolean) {
            handler.post { currentInputConnection?.commitText(text, 1) }
        }

        @JavascriptInterface
        fun deleteBackward() {
            handler.post { currentInputConnection?.deleteSurroundingText(1, 0) }
        }

        /** Metni sistemin panosuna güvenilir şekilde kopyalar (native Android ClipboardManager). */
        @JavascriptInterface
        fun copyToClipboard(text: String) {
            handler.post {
                val cm = getSystemService(CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("Tengwar", text))
            }
        }

        /** Hedef uygulamada o an seçili metni okuyup Arşiv'e ekler (varsa true döner). */
        @JavascriptInterface
        fun saveSelectedToArchive(): Boolean {
            var saved = false
            runOnUiThreadBlocking {
                val ic = currentInputConnection
                // Bazı WebView tabanlı yazı alanları (ör. kendi uygulamamızın içindeki
                // deneme kutusu) getSelectedText'i düzgün desteklemeyebiliyor —
                // bu yüzden bir de ExtractedText üzerinden yedek bir yol deniyoruz.
                var selected = ic?.getSelectedText(0)?.toString()
                if (selected.isNullOrBlank()) {
                    val req = android.view.inputmethod.ExtractedTextRequest()
                    val extracted = ic?.getExtractedText(req, 0)
                    if (extracted != null && extracted.selectionStart >= 0 && extracted.selectionEnd > extracted.selectionStart) {
                        val full = extracted.text?.toString() ?: ""
                        if (extracted.selectionEnd <= full.length) {
                            selected = full.substring(extracted.selectionStart, extracted.selectionEnd)
                        }
                    }
                }
                if (!selected.isNullOrBlank()) {
                    val words = archiveWords()
                    if (!words.contains(selected)) {
                        words.add(selected)
                        if (words.size > 20) words.removeAt(0) // kelime sınırı 20
                        saveArchiveWordsList(words)
                    }
                    saved = true
                }
            }
            return saved
        }

        /** Kayıtlı arşiv kelimelerini basit bir JSON dizisi (["kelime1","kelime2",...]) olarak döner. */
        @JavascriptInterface
        fun getArchiveWordsJson(): String {
            var json = "[]"
            runOnUiThreadBlocking {
                val words = archiveWords()
                json = "[" + words.joinToString(",") { jsonStringLiteral(it) } + "]"
            }
            return json
        }
    }

    private fun jsonStringLiteral(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                else -> sb.append(c)
            }
        }
        sb.append("\"")
        return sb.toString()
    }

    // ---- Arşiv depolama (SharedPreferences, "||" ile ayrılmış tek metin) ----

    private fun archiveWords(): MutableList<String> {
        val raw = getSharedPreferences("tengwar_archive", MODE_PRIVATE).getString("words", "") ?: ""
        return if (raw.isEmpty()) mutableListOf() else raw.split("||").filter { it.isNotEmpty() }.toMutableList()
    }

    private fun saveArchiveWordsList(words: List<String>) {
        getSharedPreferences("tengwar_archive", MODE_PRIVATE).edit()
            .putString("words", words.joinToString("||"))
            .apply()
    }

    /** JsBridge metodları WebView'in arka plan thread'inde çalıştığı için,
     *  InputConnection/SharedPreferences işlemlerini burada ana thread'e
     *  taşıyıp senkron şekilde bekliyoruz (JS tarafı bir dönüş değeri bekliyor). */
    private fun runOnUiThreadBlocking(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        handler.post {
            try { block() } finally { latch.countDown() }
        }
        latch.await()
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()
}
