package com.tengwar.klavye

import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Türkçe Tengwar-Quenya sistem klavyesi.
 *
 * Bu servis, TTQ-Klavye.txt web referansındaki dört modlu (Standart / Shift /
 * AltGr / Shift+AltGr) tuş haritasını (bkz. KeymapData.kt) native bir
 * Android klavyeye taşır. Herhangi bir uygulamada metin alanına dokunulduğunda
 * bu klavye devreye girer ve seçilen tengwa karakterini doğrudan o uygulamaya
 * yazar (InputConnection.commitText).
 */
class TengwarIME : InputMethodService() {

    private enum class Mode { STANDARD, SHIFT, ALTGR, SHIFT_ALTGR }

    private var mode: Mode = Mode.STANDARD
    private lateinit var tengwarTypeface: Typeface

    override fun onCreate() {
        super.onCreate()
        tengwarTypeface = Typeface.createFromAsset(assets, "fonts/TengwarAnnatar.ttf")
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) {
            mode = Mode.STANDARD
        }
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#364963"))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        root.addView(
            buildRow(
                cells = KeymapData.rowA,
                leading = null,
                trailing = specialKeySpec("⌫", widthWeight = 1.9f) { deleteBackward() }
            )
        )
        root.addView(
            buildRow(
                cells = KeymapData.rowB,
                leading = specialKeySpec("Tab", widthWeight = 1.15f) { commitText("\t") },
                trailing = specialKeySpec("↵", widthWeight = 1.9f) { commitText("\n") }
            )
        )
        root.addView(
            buildRow(
                cells = KeymapData.rowC,
                leading = specialKeySpec(
                    "Caps",
                    widthWeight = 1.15f,
                    isActive = { mode == Mode.SHIFT || mode == Mode.SHIFT_ALTGR }
                ) { toggleShift() },
                trailing = null
            )
        )
        root.addView(
            buildRow(
                cells = KeymapData.rowD,
                leading = specialKeySpec(
                    "Shift",
                    widthWeight = 1.9f,
                    isActive = { mode == Mode.SHIFT || mode == Mode.SHIFT_ALTGR }
                ) { toggleShift() },
                trailing = specialKeySpec(
                    "Shift",
                    widthWeight = 1.9f,
                    isActive = { mode == Mode.SHIFT || mode == Mode.SHIFT_ALTGR }
                ) { toggleShift() }
            )
        )
        root.addView(buildBottomRow())

        return root
    }

    /** Ctrl / Alt / Boşluk / AltGr / Ctrl satırı. */
    private fun buildBottomRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
            ).apply { setMargins(0, dp(3), 0, 0) }
        }
        row.addView(makeSpecialView(specialKeySpec("Ctrl", widthWeight = 1.15f, enabled = false) {}))
        row.addView(makeSpecialView(specialKeySpec("Alt", widthWeight = 1.15f, enabled = false) {}))
        row.addView(makeSpecialView(specialKeySpec("Boşluk", widthWeight = 9f) { commitText(" ") }))
        row.addView(
            makeSpecialView(
                specialKeySpec(
                    "AltGr",
                    widthWeight = 1.15f,
                    isActive = { mode == Mode.ALTGR || mode == Mode.SHIFT_ALTGR }
                ) { toggleAltgr() }
            )
        )
        row.addView(makeSpecialView(specialKeySpec("Ctrl", widthWeight = 1.15f, enabled = false) {}))
        return row
    }

    private data class SpecialKeySpec(
        val label: String,
        val widthWeight: Float,
        val enabled: Boolean = true,
        val isActive: (() -> Boolean)? = null,
        val onClick: () -> Unit
    )

    private fun specialKeySpec(
        label: String,
        widthWeight: Float,
        enabled: Boolean = true,
        isActive: (() -> Boolean)? = null,
        onClick: () -> Unit
    ) = SpecialKeySpec(label, widthWeight, enabled, isActive, onClick)

    private fun buildRow(
        cells: List<KeyCell>,
        leading: SpecialKeySpec?,
        trailing: SpecialKeySpec?
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
            ).apply { setMargins(0, dp(3), 0, 0) }
        }
        leading?.let { row.addView(makeSpecialView(it)) }
        for (cell in cells) {
            row.addView(makeKeyView(cell))
        }
        trailing?.let { row.addView(makeSpecialView(it)) }
        return row
    }

    private fun variantFor(cell: KeyCell): KeyVariant = when (mode) {
        Mode.STANDARD -> cell.standard
        Mode.SHIFT -> cell.shift
        Mode.ALTGR -> cell.altgr
        Mode.SHIFT_ALTGR -> cell.shiftAltgr
    }

    /** Tengwa harfi/işareti tuşu: üstte küçük Türkçe etiket, ortada büyük tengwa glifi. */
    private fun makeKeyView(cell: KeyCell): FrameLayout {
        val variant = variantFor(cell)

        val container = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }

        if (variant.glyph == null) {
            container.setBackgroundColor(Color.parseColor("#E6E6E6"))
            return container
        }

        container.setBackgroundColor(Color.WHITE)
        container.isClickable = true
        container.isFocusable = true

        val glyphView = TextView(this).apply {
            typeface = tengwarTypeface
            text = variant.glyph
            textSize = 19f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        }

        val labelGravity = if (variant.desc) {
            if (variant.labelPos == "bottom") Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            else Gravity.TOP or Gravity.CENTER_HORIZONTAL
        } else {
            Gravity.BOTTOM or Gravity.END
        }
        val labelView = TextView(this).apply {
            text = variant.label
            textSize = 9f
            setTextColor(Color.DKGRAY)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = labelGravity
                setMargins(dp(2), dp(1), dp(2), dp(1))
            }
        }

        container.addView(glyphView)
        container.addView(labelView)

        container.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            commitText(variant.glyph)
        }

        return container
    }

    private fun makeSpecialView(spec: SpecialKeySpec): TextView {
        val active = spec.isActive?.invoke() ?: false
        return TextView(this).apply {
            text = spec.label
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(if (active) Color.parseColor("#222222") else Color.WHITE)
            setBackgroundColor(
                if (active) Color.parseColor("#FFCC00")
                else Color.parseColor("#1E5A2C")
            )
            alpha = if (spec.enabled) 1f else 0.5f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, spec.widthWeight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            if (spec.enabled) {
                isClickable = true
                setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    spec.onClick()
                }
            }
        }
    }

    private fun toggleShift() {
        mode = when (mode) {
            Mode.STANDARD -> Mode.SHIFT
            Mode.SHIFT -> Mode.STANDARD
            Mode.ALTGR -> Mode.SHIFT_ALTGR
            Mode.SHIFT_ALTGR -> Mode.ALTGR
        }
        refreshKeyboard()
    }

    private fun toggleAltgr() {
        mode = when (mode) {
            Mode.STANDARD -> Mode.ALTGR
            Mode.ALTGR -> Mode.STANDARD
            Mode.SHIFT -> Mode.SHIFT_ALTGR
            Mode.SHIFT_ALTGR -> Mode.SHIFT
        }
        refreshKeyboard()
    }

    private fun refreshKeyboard() {
        setInputView(onCreateInputView())
    }

    private fun commitText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun deleteBackward() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()
}
