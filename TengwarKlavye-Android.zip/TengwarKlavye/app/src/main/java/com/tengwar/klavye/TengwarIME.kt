package com.tengwar.klavye

import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.inputmethodservice.InputMethodService
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

/**
 * Türkçe Tengwar-Quenya sistem klavyesi (v2 — basılı tutma / long-press tabanlı).
 *
 * Bu servis, artık Shift/AltGr modları yerine standart telefon klavyelerindeki
 * gibi "basılı tutunca alternatifler açılır" mantığını kullanıyor. Tasarım,
 * sohbette birlikte geliştirdiğimiz HTML önizlemesinin (tengwar-android-onizleme.html)
 * native Android karşılığıdır. Bazı ince görsel detaylar (özellikle bazı
 * gliflerin piksel-mükemmel ortalanması) web önizlemesindeki kadar hassas
 * olmayabilir — Android'in metin ölçüm modeli CSS'ten farklı çalışıyor.
 */
class TengwarIME : InputMethodService() {

    private lateinit var tengwarTypeface: Typeface
    private val handler = Handler(Looper.getMainLooper())

    private enum class Page { LETTERS, SYMBOLS, EMOJI, ENGLISH }
    private var currentPage = Page.LETTERS

    private lateinit var stack: FrameLayout
    private lateinit var pageLetters: View
    private lateinit var pageSymbols: View
    private lateinit var pageEmoji: View
    private lateinit var pageEnglish: View

    private var activePopup: PopupWindow? = null

    // ---- StringBuilder yerine doğrudan hedef uygulamaya yazıyoruz; burada sadece silme/boşluk tekrarı için durum tutuyoruz ----
    private val vowelLabels = setOf("A", "U", "I", "O", "İ", "Ö", "Ü", "Ě", "E")

    /** Basılı tutma popup'ı için tek bir seçenek: ekranda görünen ile yazılan farklı olabilir. */
    data class Opt(val display: String, val output: String, val plain: Boolean = false)

    /** Ana klavye için genel tuş tanımı (KeyCell'den ya da elle üretilir). */
    data class KeyDef(
        val glyph: String?,
        val label: String = "",
        val plain: Boolean = false,
        val alternates: List<Opt> = emptyList(),
        val numbered: Boolean = false,
        val numberPos: String = "bottom", // "bottom" | "bottomRight" | "top"
        val big: Boolean = false
    )

    private fun KeyCell.toKeyDef(numbered: Boolean = false, numberPos: String = "bottom"): KeyDef {
        val seen = linkedSetOf<String>()
        standard.glyph?.let { seen.add(it) }
        val alts = mutableListOf<Opt>()
        listOf(shift, altgr, shiftAltgr).forEach { v ->
            val g = v.glyph
            if (g != null && !seen.contains(g)) {
                seen.add(g)
                alts.add(Opt(g, g))
            }
        }
        val isVowel = vowelLabels.contains(standard.label)
        return KeyDef(standard.glyph, standard.label, false, alts, numbered || isVowel, if (isVowel) "bottom" else numberPos, isVowel)
    }

    override fun onCreate() {
        super.onCreate()
        tengwarTypeface = Typeface.createFromAsset(assets, "fonts/TengwarAnnatar.ttf")
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) currentPage = Page.LETTERS
        updatePageVisibility()
    }

    // =========================================================================================
    // Sayfa iskeleti
    // =========================================================================================

    override fun onCreateInputView(): View {
        stack = FrameLayout(this)

        pageLetters = buildLettersPage()
        pageSymbols = buildSymbolsPage()
        pageEmoji = buildEmojiPage()
        pageEnglish = buildEnglishPage()

        stack.addView(pageLetters)
        stack.addView(pageSymbols)
        stack.addView(pageEmoji)
        stack.addView(pageEnglish)
        updatePageVisibility()
        return stack
    }

    private fun showPage(p: Page) {
        currentPage = p
        updatePageVisibility()
        dismissPopup()
    }

    private fun updatePageVisibility() {
        if (!::pageLetters.isInitialized) return
        pageLetters.visibility = if (currentPage == Page.LETTERS) View.VISIBLE else View.GONE
        pageSymbols.visibility = if (currentPage == Page.SYMBOLS) View.VISIBLE else View.GONE
        pageEmoji.visibility = if (currentPage == Page.EMOJI) View.VISIBLE else View.GONE
        pageEnglish.visibility = if (currentPage == Page.ENGLISH) View.VISIBLE else View.GONE
    }

    // =========================================================================================
    // HARFLER SAYFASI
    // =========================================================================================

    private fun buildLettersPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1b2e24"))
            setPadding(dp(4), dp(6), dp(4), dp(9))
        }

        col.addView(header())

        // Sayı sırası (koyu yeşil, 10 tuş) — Satır A'nın 1-9,0 karşılığı
        val numberRow = KeymapData.rowA.subList(1, 11)
        col.addView(buildRow(numberRow.map { it.toKeyDef() }, plainStyle = false, darkStyle = true))
        col.addView(dividerView())

        // Satır B (12), Satır C (virgülsüz, 11), Satır D (kuyruk ve nokta çıkarılmış, 9) + silme
        col.addView(buildRow(KeymapData.rowB.map { it.toKeyDef() }))
        val rowCNoComma = KeymapData.rowC.subList(0, KeymapData.rowC.size - 1)
        col.addView(buildRow(rowCNoComma.map { it.toKeyDef() }))

        val tailCellData = KeymapData.rowD[0]
        val rowDInner = KeymapData.rowD.subList(1, KeymapData.rowD.size - 1)
        val backspaceBtn = makeBackspaceButton()
        col.addView(buildRow(rowDInner.map { it.toKeyDef() }, trailing = backspaceBtn))

        // 3 mini düğme: "<", Yumuşatma, Çiftleme
        col.addView(buildMiniRow(tailCellData))

        col.addView(bottomControlRow(showSymBtn = true))
        return col
    }

    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(7))
        }
        val t = TextView(this).apply {
            text = "Tengwar Academy"
            setTextColor(Color.parseColor("#f2d68a"))
            textSize = 10f
        }
        row.addView(t)
        return row
    }

    private fun dividerView(): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                setMargins(0, dp(2), 0, dp(7))
            }
            setBackgroundColor(Color.parseColor("#66c9a24b"))
        }
    }

    private fun buildMiniRow(tailCellData: KeyCell): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)).apply {
                setMargins(0, dp(4), 0, 0)
            }
        }
        val tireCell = KeymapData.rowA[12] // standart Ì, alternatifler Í / Î
        val ciftlemeDef = KeyDef(
            "P", "", false,
            listOf(Opt(":", ":"), Opt("p", "p"), Opt("°", "°"), Opt(";", ";")),
            numbered = true, numberPos = "top"
        )
        row.addView(miniLabeledButton(tailCellData.toKeyDef(numbered = true, numberPos = "top"), "ÁRA KUYRUĞU"))
        row.addView(miniLabeledButton(tireCell.toKeyDef(numbered = true, numberPos = "top"), "YUMUŞATMA"))
        row.addView(miniLabeledButton(ciftlemeDef, "ÇİFTLEME"))
        return row
    }

    private fun miniLabeledButton(def: KeyDef, labelText: String): View {
        val btn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#17251d"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }
        val lbl = TextView(this).apply {
            text = labelText
            textSize = 7.5f
            setTextColor(Color.parseColor("#e4ecd9"))
        }
        val glyph = TextView(this).apply {
            typeface = tengwarTypeface
            text = def.glyph
            textSize = 15f
            setTextColor(Color.parseColor("#e4ecd9"))
            setPadding(dp(4), 0, 0, 0)
        }
        btn.addView(lbl)
        btn.addView(glyph)
        attachKeyBehavior(btn, def)
        return btn
    }

    // =========================================================================================
    // SAYILAR / SEMBOLLER SAYFASI
    // =========================================================================================

    private fun buildSymbolsPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1b2e24"))
            setPadding(dp(4), dp(6), dp(4), dp(9))
        }
        col.addView(header())

        // Satır A: Tırnak (ilk) ve Tire (son) çıkarılmış — 10 tuş
        val rowA = KeymapData.rowA.subList(1, KeymapData.rowA.size - 1)
        col.addView(buildRow(rowA.map { it.toKeyDef() }, darkStyle = true))
        col.addView(dividerView())

        // Noktalama ızgarası + matematik kutusu yan yana
        val punctRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val grid = buildPunctGrid()
        val gridParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        grid.layoutParams = gridParams
        punctRow.addView(grid)
        punctRow.addView(buildMathBox())
        col.addView(punctRow)

        // Hızlı yazım: ".com" / "@gmail.com"
        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)).apply {
                setMargins(0, dp(5), 0, 0)
            }
        }
        quickRow.addView(quickTextButton(".com"))
        quickRow.addView(quickTextButton("@gmail.com"))
        col.addView(quickRow)

        col.addView(bottomControlRow(showSymBtn = false))
        return col
    }

    private val punctList: List<Triple<String, Boolean, List<Opt>>> by lazy {
        // (glyph, plain?, alternatifler)
        listOf(
            Triple("«", false, emptyList()),
            Triple("Á", false, emptyList()),
            Triple("²", false, emptyList()),
            Triple("›", false, emptyList()),
            Triple("Œ", false, emptyList()),
            Triple("œ", false, emptyList()),
            Triple("¬", false, emptyList()),
            Triple("À", false, emptyList()),
            Triple("Â", false, emptyList()),
            Triple("/", true, listOf(Opt("\\", "\\", true))),
            Triple("<", true, emptyList()),
            Triple(">", true, emptyList()),
            Triple("[", true, listOf(Opt("{", "{", true))),
            Triple("]", true, listOf(Opt("}", "}", true))),
            Triple("@", true, emptyList()),
            Triple("#", true, emptyList()),
            Triple("₺", true, listOf(
                Opt("$", "$", true), Opt("€", "€", true), Opt("₽", "₽", true),
                Opt("元", "元", true), Opt("¥", "¥", true), Opt("£", "£", true)
            )),
            Triple("%", true, emptyList()),
            Triple("^", true, emptyList()),
            Triple("&", true, emptyList()),
            Triple("*", true, emptyList()),
            Triple("|", true, emptyList()),
            Triple("_", true, emptyList()),
            Triple("°", true, emptyList()),
            Triple("§", true, emptyList()),
            Triple("±", true, emptyList()),
            Triple("•", true, emptyList()),
            Triple("©", true, emptyList()),
            Triple("®", true, emptyList()),
            Triple("™", true, emptyList())
        )
    }

    private fun buildPunctGrid(): View {
        val grid = GridLayout(this).apply {
            columnCount = 10
            useDefaultMargins = false
        }
        for ((glyph, plain, alts) in punctList) {
            val def = KeyDef(glyph, "", plain, alts, numbered = alts.isNotEmpty(), numberPos = "top")
            grid.addView(gridKeyButton(def))
        }
        return grid
    }

    private fun gridKeyButton(def: KeyDef): View {
        val btn = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#F0FFFFFF"))
            val lp = GridLayout.LayoutParams()
            lp.width = dp(34)
            lp.height = dp(36)
            lp.setMargins(dp(1), dp(1), dp(1), dp(1))
            layoutParams = lp
        }
        val glyph = TextView(this).apply {
            typeface = if (def.plain) Typeface.DEFAULT_BOLD else tengwarTypeface
            text = def.glyph
            textSize = if (def.plain) 13f else 16f
            setTextColor(Color.parseColor("#1c1f28"))
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        btn.addView(glyph)
        attachKeyBehavior(btn, def)
        return btn
    }

    private fun buildMathBox(): View {
        val grid = GridLayout(this).apply {
            columnCount = 2
            layoutParams = LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        listOf("+", "-", "×", "÷").forEach { ch ->
            val btn = TextView(this).apply {
                text = ch
                textSize = 16f
                setTextColor(Color.parseColor("#e4ecd9"))
                setBackgroundColor(Color.parseColor("#17251d"))
                gravity = Gravity.CENTER
                val lp = GridLayout.LayoutParams()
                lp.width = dp(38); lp.height = dp(38)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                layoutParams = lp
            }
            attachKeyBehavior(btn, KeyDef(ch, "", true))
            grid.addView(btn)
        }
        // Silme tuşu: "×"in altına (3. satır, 1. sütun)
        val backspaceBtn = makeBackspaceButton()
        val lp = GridLayout.LayoutParams()
        lp.width = dp(38); lp.height = dp(38)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        backspaceBtn.layoutParams = lp
        grid.addView(backspaceBtn)
        return grid
    }

    private fun quickTextButton(text: String): View {
        val btn = TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(Color.parseColor("#e4ecd9"))
            setBackgroundColor(Color.parseColor("#17251d"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }
        btn.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            commitOutput(text)
        }
        return btn
    }

    // =========================================================================================
    // EMOJİ SAYFASI
    // =========================================================================================

    private val emojiCategories: List<Pair<String, String>> = listOf(
        "😀" to "😀😁😂🤣😊😍😘😜🤔😎😴😭😡🥳😇🙃😅😆🥰😋🤗🤩😏😬🥺😱😳🤯🤤",
        "🐶" to "🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🐔🐧🐦🐤🦄🐴🐗🐺🦉🐢🐍🦋🐝🐳🐬",
        "🍔" to "🍏🍎🍊🍋🍌🍉🍇🍓🍒🍑🥝🍅🍕🍔🍟🌭🥪🌮🌯🍿🍩🍪🍰🎂🍫🍬🍭🍦☕🍺",
        "⚽" to "⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥊🥋⛳🎯🎳🎮🎲🧩🎸🎨🎬🎤🎧🚴🏊🏋️🧗🏆🥇🎽",
        "🚗" to "🚗🚕🚙🚌🚎🏎️🚓🚑🚒🚚🚲🛵🏍️✈️🚀🚁⛵🚤🚢🚂🚉🗺️🗽🗼🏰🏯🏟️🎡🎢⛱️",
        "💡" to "💡📱💻⌨️🖥️🖨️📷📸🎥📺📻⏰⏱️🔋🔌💾💿📀📚📖✏️✂️🔑🔒🔓🧲🧰🔧🔨🪓🧱",
        "🔣" to "❤️🧡💛💚💙💜🖤🤍💔❣️💕💞💓💗💖💘💝💯💢💥💫💦💨🕳️💣🔥⭐🌟✨"
    )

    private fun buildEmojiPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1b2e24"))
            setPadding(dp(4), dp(6), dp(4), dp(9))
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val gridHolder = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)).apply {
                setMargins(0, dp(6), 0, 0)
            }
        }

        fun renderCategory(items: String) {
            gridHolder.removeAllViews()
            val scroll = ScrollView(this)
            val grid = GridLayout(this).apply { columnCount = 8 }
            for (ch in items) {
                val b = TextView(this).apply {
                    text = ch.toString()
                    textSize = 16f
                    gravity = Gravity.CENTER
                    setBackgroundColor(Color.parseColor("#F0FFFFFF"))
                    val lp = GridLayout.LayoutParams()
                    lp.width = dp(34); lp.height = dp(34)
                    lp.setMargins(dp(1), dp(1), dp(1), dp(1))
                    layoutParams = lp
                }
                b.setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    commitOutput(ch.toString())
                }
                grid.addView(b)
            }
            scroll.addView(grid)
            gridHolder.addView(scroll)
        }

        emojiCategories.forEachIndexed { i, (icon, items) ->
            val tabBtn = TextView(this).apply {
                text = icon
                textSize = 14f
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#17251d"))
                layoutParams = LinearLayout.LayoutParams(0, dp(32), 1f).apply {
                    setMargins(dp(1), 0, dp(1), 0)
                }
            }
            tabBtn.setOnClickListener { renderCategory(items) }
            tabs.addView(tabBtn)
        }
        col.addView(tabs)
        col.addView(gridHolder)
        if (emojiCategories.isNotEmpty()) renderCategory(emojiCategories[0].second)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply {
                setMargins(0, dp(6), 0, 0)
            }
        }
        bottom.addView(specialButton("ABC", 1.4f) { showPage(Page.LETTERS) })
        bottom.addView(specialButton("␣", 5.2f) { commitOutput(" ") })
        bottom.addView(specialButton("↵", 1.9f) { commitOutput("\n") })
        col.addView(bottom)
        return col
    }

    // =========================================================================================
    // İNGİLİZCE QWERTY SAYFASI
    // =========================================================================================

    private fun buildEnglishPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1b2e24"))
            setPadding(dp(4), dp(6), dp(4), dp(9))
        }
        col.addView(plainRow(listOf("Q","W","E","R","T","Y","U","I","O","P")))
        col.addView(plainRow(listOf("A","S","D","F","G","H","J","K","L")))
        col.addView(plainRow(listOf("Z","X","C","V","B","N","M"), trailing = makeBackspaceButton()))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply {
                setMargins(0, dp(5), 0, 0)
            }
        }
        bottom.addView(specialButton("123", 1.4f) { showPage(Page.SYMBOLS) })
        bottom.addView(specialButton(",", 1.15f) { commitOutput(",") })
        val spaceBtn = specialButton("English (kaydır: Tengwar)", 5.2f) {}
        attachSpaceBehavior(spaceBtn, toEnglish = false)
        bottom.addView(spaceBtn)
        bottom.addView(specialButton(".", 1.15f) { commitOutput(".") })
        bottom.addView(specialButton("↵", 1.4f) { commitOutput("\n") })
        col.addView(bottom)
        return col
    }

    private fun plainRow(letters: List<String>, trailing: View? = null): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(0, dp(3), 0, 0)
            }
        }
        for (l in letters) {
            val b = TextView(this).apply {
                text = l
                textSize = 16f
                gravity = Gravity.CENTER
                setBackgroundColor(Color.WHITE)
                setTextColor(Color.parseColor("#1c1f28"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
            }
            b.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                commitOutput(l, plain = true)
            }
            row.addView(b)
        }
        trailing?.let { row.addView(it) }
        return row
    }

    // =========================================================================================
    // Alt kontrol satırı (emoji / 123-ABC / virgül / boşluk / nokta / enter)
    // =========================================================================================

    private fun bottomControlRow(showSymBtn: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(0, dp(5), 0, 0)
            }
        }
        row.addView(specialButton("😀", 1.4f) { showPage(Page.EMOJI) })
        if (showSymBtn) {
            row.addView(specialButton("123", 1.4f) { showPage(Page.SYMBOLS) })
        } else {
            row.addView(specialButton("ABC", 1.4f) { showPage(Page.LETTERS) })
        }
        val commaCell = KeymapData.rowC.last()
        val periodCell = KeymapData.rowD.last()
        row.addView(smallGlyphButton(commaCell.standard.glyph ?: ",", listOf(
            Opt(commaCell.shift.glyph ?: "", commaCell.shift.glyph ?: ""),
            Opt("-", "-"),
            Opt(commaCell.altgr.glyph ?: "", commaCell.altgr.glyph ?: "")
        )))
        val spaceBtn = specialButton("w^dj&z", 5.2f) {}
        attachSpaceBehavior(spaceBtn, toEnglish = true)
        row.addView(spaceBtn)
        row.addView(smallGlyphButton(periodCell.standard.glyph ?: ".", listOf(
            Opt("~º", "º"), Opt("jL", "L"), Opt("iË", "Ë"), Opt("9Ê", "Ê")
        )))
        row.addView(specialButton("↵", 1.9f) { commitOutput("\n") })
        return row
    }

    private fun smallGlyphButton(glyph: String, alternates: List<Opt>): View {
        val btn = TextView(this).apply {
            typeface = tengwarTypeface
            text = glyph
            textSize = 20f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#17251d"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.15f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }
        attachKeyBehavior(btn, KeyDef(glyph, "", false, alternates, numbered = true, numberPos = "top"))
        return btn
    }

    private fun specialButton(label: String, weight: Float, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = if (label.length > 3) 9f else 15f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#e4ecd9"))
            setBackgroundColor(Color.parseColor("#17251d"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }
    }

    private fun makeBackspaceButton(): View {
        val btn = TextView(this).apply {
            text = "⌫"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#e4ecd9"))
            setBackgroundColor(Color.parseColor("#17251d"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }
        var repeating = false
        val repeatRunnable = object : Runnable {
            override fun run() {
                deleteBackward()
                handler.postDelayed(this, 70)
            }
        }
        btn.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    repeating = false
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    deleteBackward()
                    handler.postDelayed({ repeating = true; handler.post(repeatRunnable) }, 380)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeatRunnable)
                    true
                }
                else -> false
            }
        }
        return btn
    }

    private fun attachSpaceBehavior(view: TextView, toEnglish: Boolean) {
        var startX = 0f
        var swiped = false
        var repeating = false
        val threshold = dp(40)
        val repeatRunnable = object : Runnable {
            override fun run() {
                commitOutput(" ")
                handler.postDelayed(this, 70)
            }
        }
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    swiped = false
                    repeating = false
                    handler.postDelayed({
                        if (!swiped) {
                            repeating = true
                            commitOutput(" ")
                            handler.post(repeatRunnable)
                        }
                    }, 380)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.rawX - startX) > threshold) swiped = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(repeatRunnable)
                    if (swiped) {
                        showPage(if (toEnglish) Page.ENGLISH else Page.LETTERS)
                    } else if (!repeating) {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        commitOutput(" ")
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(repeatRunnable); true }
                else -> false
            }
        }
    }

    // =========================================================================================
    // Ortak satır/tuş inşası
    // =========================================================================================

    private fun buildRow(defs: List<KeyDef>, plainStyle: Boolean = false, darkStyle: Boolean = false, trailing: View? = null): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(0, dp(3), 0, 0)
            }
        }
        for (def in defs) {
            row.addView(keyButtonView(def, darkStyle))
        }
        trailing?.let { row.addView(it) }
        return row
    }

    private fun keyButtonView(def: KeyDef, darkStyle: Boolean): View {
        if (def.glyph == null) {
            return View(this).apply {
                setBackgroundColor(Color.parseColor(if (darkStyle) "#0f1a14" else "#1AFFFFFF"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(1), 0, dp(1), 0)
                }
            }
        }
        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor(if (darkStyle) "#17251d" else "#FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(1), 0, dp(1), 0)
            }
        }
        val textColor = if (darkStyle) Color.parseColor("#e4ecd9") else Color.parseColor("#1c1f28")
        val glyphView = TextView(this).apply {
            typeface = tengwarTypeface
            text = def.glyph
            textSize = if (def.big) 21f else 17f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        container.addView(glyphView)
        if (def.label.isNotEmpty()) {
            val isDigit = def.label.length == 1 && def.label[0].isDigit()
            val lbl = TextView(this).apply {
                text = def.label
                textSize = if (isDigit) 9f else 8f
                setTextColor(if (darkStyle) Color.parseColor("#CCe4ecd9") else Color.parseColor("#991c1f28"))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = if (isDigit) Gravity.TOP or Gravity.CENTER_HORIZONTAL
                              else if (vowelLabels.contains(def.label)) Gravity.BOTTOM or Gravity.END
                              else Gravity.TOP or Gravity.END
                    setMargins(dp(2), dp(1), dp(2), dp(1))
                }
            }
            container.addView(lbl)
        }
        attachKeyBehavior(container, def)
        return container
    }

    // =========================================================================================
    // Basılı tutma / kısa dokunma davranışı (tüm tuşlar için ortak)
    // =========================================================================================

    private fun attachKeyBehavior(view: View, def: KeyDef) {
        var longPressed = false
        var hovered: TextView? = null
        var optionViews: List<Pair<TextView, Opt>> = emptyList()
        val longPressRunnable = Runnable {
            if (def.alternates.isNotEmpty()) {
                longPressed = true
                val (popup, views) = buildPopup(def)
                optionViews = views
                showPopupAbove(popup, view)
            }
        }

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longPressed = false
                    v.isPressed = true
                    handler.postDelayed(longPressRunnable, 380)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (longPressed) {
                        val rawX = event.rawX
                        val rawY = event.rawY
                        var found: TextView? = null
                        for ((optView, _) in optionViews) {
                            val loc = IntArray(2)
                            optView.getLocationOnScreen(loc)
                            if (rawX >= loc[0] && rawX <= loc[0] + optView.width &&
                                rawY >= loc[1] && rawY <= loc[1] + optView.height
                            ) {
                                found = optView
                            }
                        }
                        if (found !== hovered) {
                            hovered?.setBackgroundColor(Color.parseColor("#1f3527"))
                            hovered = found
                            hovered?.setBackgroundColor(Color.parseColor("#c9a24b"))
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    handler.removeCallbacks(longPressRunnable)
                    if (longPressed) {
                        val chosen = optionViews.firstOrNull { it.first === hovered }?.second
                        if (chosen != null) commitOutput(chosen.output, chosen.plain)
                        dismissPopup()
                    } else {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        def.glyph?.let { commitOutput(it, def.plain) }
                    }
                    hovered = null
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(longPressRunnable)
                    dismissPopup()
                    hovered = null
                    true
                }
                else -> false
            }
        }
    }

    private fun buildPopup(def: KeyDef): Pair<PopupWindow, List<Pair<TextView, Opt>>> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#13231a"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val views = mutableListOf<Pair<TextView, Opt>>()
        for ((i, opt) in def.alternates.withIndex()) {
            val optContainer = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(46)).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
            }
            val tv = TextView(this).apply {
                typeface = if (opt.plain) Typeface.DEFAULT_BOLD else tengwarTypeface
                text = opt.display
                textSize = if (opt.plain) 15f else 19f
                setTextColor(Color.parseColor("#f3ecda"))
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#1f3527"))
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }
            optContainer.addView(tv)
            if (def.numbered) {
                val num = TextView(this).apply {
                    text = if (def.glyph == "·" && i == 1) "2*" else (i + 1).toString()
                    textSize = 8f
                    setTextColor(Color.parseColor("#e2c785"))
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        gravity = when (def.numberPos) {
                            "top" -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                            "bottomRight" -> Gravity.BOTTOM or Gravity.END
                            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                        }
                    }
                }
                optContainer.addView(num)
            }
            views.add(tv to opt)
            row.addView(optContainer)
        }
        val popup = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        return popup to views
    }

    private fun showPopupAbove(popup: PopupWindow, anchor: View) {
        dismissPopup()
        activePopup = popup
        popup.isOutsideTouchable = true
        popup.showAsDropDown(anchor, 0, -(anchor.height + dp(52)), Gravity.CENTER)
    }

    private fun dismissPopup() {
        activePopup?.dismiss()
        activePopup = null
    }

    // =========================================================================================
    // Yardımcılar
    // =========================================================================================

    private fun commitOutput(text: String, plain: Boolean = false) {
        // NOT: Yazılan metin hedef uygulamaya (Notlar, WhatsApp vb.) gönderiliyor.
        // O uygulama kendi fontunu kullanır — Tengwar karakterlerinin doğru şekilde
        // görünmesi için hedef uygulamada da bu fontun yüklü olması gerekir; bu,
        // klavyemizin kendi görünümünden bağımsız bir kısıtlamadır.
        currentInputConnection?.commitText(text, 1)
    }

    private fun deleteBackward() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()
}
